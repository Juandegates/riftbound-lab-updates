extends Node2D
# Correccion remota de rig existente; no reemplaza scripts empaquetados.
# Se aplica a los rig_nodes creados por EnemyVisual.
var elapsed := 0.0
var patched := {}
var positions := {
    "BackLegUpper": Vector2(0, 13), "BackLegLower": Vector2(0, 12), "BackBoot": Vector2(0, 6),
    "FrontLegUpper": Vector2(0, 13), "FrontLegLower": Vector2(0, 12), "FrontBoot": Vector2(0, 6),
    "PelvisArmor": Vector2(0, 0), "BodyArmor": Vector2(0, 0),
    "NeckArmor": Vector2(0, 1), "Helm": Vector2(0, -2), "Halo": Vector2(0, -2),
    "BackArmUpper": Vector2(0, 10), "BackArmLower": Vector2(0, 9), "BackGlove": Vector2(0, 4),
    "FrontArmUpper": Vector2(0, 10), "FrontGauntlet": Vector2(0, 9), "FrontHandSprite": Vector2(0, 4),
    "Cape": Vector2(0, 7)
}
var layers := {
    "Halo": 0, "Cape": 1,
    "BackLegUpper": 2, "BackLegLower": 2, "BackBoot": 2,
    "BackArmUpper": 3, "BackArmLower": 3, "BackGlove": 3,
    "FrontLegUpper": 4, "FrontLegLower": 4, "FrontBoot": 4,
    "PelvisArmor": 5, "BodyArmor": 7, "NeckArmor": 8, "Helm": 9,
    "FrontArmUpper": 10, "FrontGauntlet": 11, "FrontHandSprite": 12
}
func _process(delta: float) -> void:
    elapsed += delta
    var main := get_parent()
    if main == null:
        return
    var visual = main.get("enemy_visual")
    if not is_instance_valid(visual):
        return
    var rigs = visual.get("rig_nodes")
    if not rigs is Array:
        return
    for rig in rigs:
        if not is_instance_valid(rig):
            continue
        var rid := rig.get_instance_id()
        if not patched.has(rid):
            _arrange(rig)
            patched[rid] = true
        # Respaldo de respiracion si el controlador reinicia el clip idle.
        var player: AnimationPlayer = rig.get_node_or_null("AnimationPlayer")
        if player != null and rig.get("action") == "idle" and player.has_animation("idle"):
            if player.current_animation != "idle" or not player.is_playing():
                player.play("idle")
            player.seek(fposmod(elapsed, player.get_animation("idle").length), true)
func _arrange(rig: Node) -> void:
    var skeleton = rig.get_node_or_null("Skeleton2D")
    if skeleton == null:
        return
    for child_name in positions:
        var sprite = skeleton.find_child(child_name, true, false)
        if sprite is Sprite2D:
            sprite.position = positions[child_name]
            sprite.z_index = layers.get(child_name, sprite.z_index)
            sprite.z_as_relative = false
    var weapon = skeleton.find_child("WeaponSprite", true, false)
    if weapon is Node2D:
        weapon.position = Vector2(0, 4)
    var hitbox = skeleton.find_child("WeaponHitbox", true, false)
    if hitbox is Area2D:
        hitbox.position = Vector2(0, 4)
    print("[LAB REMOTE ENEMY] Rig reordenado: ", rig.get_instance_id())
